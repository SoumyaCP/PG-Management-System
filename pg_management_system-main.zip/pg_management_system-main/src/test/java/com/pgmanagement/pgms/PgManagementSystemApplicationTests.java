package com.pgmanagement.pgms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
