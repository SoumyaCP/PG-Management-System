package com.pgmanagement.pgms.model;

import jakarta.persistence.*;
import java.util.Map;
import java.util.HashMap;

@Entity
@Table(name = "food_menu")
public class FoodMenu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String dayOfWeek;

    @Column(nullable = false)
    private String breakfast;

    @Column(nullable = false)
    private String lunch;

    @Column(nullable = false)
    private String dinner;

    @Column(nullable = false)
    private boolean isActive;

    // Default constructor
    public FoodMenu() {}

    // Getters
    public Long getId() { return id; }
    public String getDayOfWeek() { return dayOfWeek; }
    public String getBreakfast() { return breakfast; }
    public String getLunch() { return lunch; }
    public String getDinner() { return dinner; }
    public boolean getIsActive() { return isActive; }

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setDayOfWeek(String dayOfWeek) { this.dayOfWeek = dayOfWeek; }
    public void setBreakfast(String breakfast) { this.breakfast = breakfast; }
    public void setLunch(String lunch) { this.lunch = lunch; }
    public void setDinner(String dinner) { this.dinner = dinner; }
    public void setIsActive(boolean isActive) { this.isActive = isActive; }
} 