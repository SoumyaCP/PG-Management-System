package com.pgmanagement.pgms.controller;

import com.pgmanagement.pgms.model.FoodMenu;
import com.pgmanagement.pgms.service.FoodMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.time.DayOfWeek;
import java.util.Arrays;

@Controller
@RequestMapping("/admin")
public class FoodMenuController {

    @Autowired
    private FoodMenuService foodMenuService;

    @GetMapping("/food-menu")
    public String showFoodMenuPage(Model model) {
        List<FoodMenu> activeMenus = foodMenuService.getActiveMenus();
        model.addAttribute("menus", activeMenus);
        model.addAttribute("days", Arrays.asList(DayOfWeek.values()));
        model.addAttribute("newMenu", new FoodMenu());
        return "admin/food-menu";
    }

    @PostMapping("/food-menu/save")
    public String saveMenu(@ModelAttribute FoodMenu menu) {
        foodMenuService.saveMenu(menu);
        return "redirect:/admin/food-menu";
    }

    @GetMapping("/food-menu/delete/{id}")
    public String deleteMenu(@PathVariable Long id) {
        foodMenuService.deleteMenu(id);
        return "redirect:/admin/food-menu";
    }

    @GetMapping("/food-menu/edit/{id}")
    public String editMenu(@PathVariable Long id, Model model) {
        FoodMenu menu = foodMenuService.getAllMenus().stream()
                .filter(m -> m.getId().equals(id))
                .findFirst()
                .orElse(null);
        
        if (menu != null) {
            model.addAttribute("menu", menu);
            model.addAttribute("days", Arrays.asList(DayOfWeek.values()));
            return "admin/edit-food-menu";
        }
        
        return "redirect:/admin/food-menu";
    }
} 