package com.pgmanagement.pgms.service.validation;

import org.springframework.stereotype.Component;

@Component
public class AdminCodeValidationStrategy implements ValidationStrategy {
    private static final String ADMIN_SECRET_CODE = "ADMIN123"; // In practice, this should be in a secure configuration
    
    @Override
    public boolean validate(String adminCode) {
        return ADMIN_SECRET_CODE.equals(adminCode);
    }
    
    @Override
    public String getErrorMessage() {
        return "Invalid admin registration code";
    }
} 