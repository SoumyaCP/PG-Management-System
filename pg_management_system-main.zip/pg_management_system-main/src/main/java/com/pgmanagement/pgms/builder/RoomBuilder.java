package com.pgmanagement.pgms.builder;

import com.pgmanagement.pgms.model.Room;
import java.math.BigDecimal;

public class RoomBuilder {
    private Long id;
    private String roomNumber;
    private String floorNumber;
    private BigDecimal rentAmount;
    private boolean available;

    public RoomBuilder withId(Long id) {
        this.id = id;
        return this;
    }

    public RoomBuilder withRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
        return this;
    }

    public RoomBuilder withFloorNumber(String floorNumber) {
        this.floorNumber = floorNumber;
        return this;
    }

    public RoomBuilder withRentAmount(BigDecimal rentAmount) {
        this.rentAmount = rentAmount;
        return this;
    }

    public RoomBuilder withAvailable(boolean available) {
        this.available = available;
        return this;
    }

    public Room build() {
        Room room = new Room();
        room.setId(id);
        room.setRoomNumber(roomNumber);
        room.setFloorNumber(floorNumber);
        room.setRentAmount(rentAmount);
        room.setAvailable(available);
        return room;
    }
}
