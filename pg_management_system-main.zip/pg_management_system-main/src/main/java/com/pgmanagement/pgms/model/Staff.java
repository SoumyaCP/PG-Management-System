package com.pgmanagement.pgms.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class Staff extends User {
    public Staff() { super(); }
    public Staff(String username, String name, String password, String email, String role) {
        super(username, name, password, email);
        setRole(role);
    }
}