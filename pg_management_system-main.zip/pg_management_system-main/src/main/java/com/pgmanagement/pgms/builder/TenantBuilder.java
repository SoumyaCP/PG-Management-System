package com.pgmanagement.pgms.builder;

import com.pgmanagement.pgms.model.Tenant;

public class TenantBuilder {
    private final Tenant tenant;

    public TenantBuilder() {
        this.tenant = new Tenant();
    }

    public TenantBuilder withId(Long id) {
        tenant.setId(id);
        return this;
    }

    public TenantBuilder withName(String name) {
        tenant.setName(name);
        return this;
    }

    public TenantBuilder withEmail(String email) {
        tenant.setEmail(email);
        return this;
    }

    public TenantBuilder withPhoneNumber(String phoneNumber) {
        tenant.setPhone(phoneNumber);
        return this;
    }

    public TenantBuilder withAddress(String address) {
        tenant.setAddress(address);
        return this;
    }

    public TenantBuilder withUsername(String username) {
        tenant.setUsername(username);
        return this;
    }

    public TenantBuilder withPassword(String password) {
        tenant.setPassword(password);
        return this;
    }

    public TenantBuilder withRole(String role) {
        tenant.setRole(role);
        return this;
    }

    public Tenant build() {
        return this.tenant;
    }
}
