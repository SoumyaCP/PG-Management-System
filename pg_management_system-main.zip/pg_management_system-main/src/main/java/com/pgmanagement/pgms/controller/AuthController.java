package com.pgmanagement.pgms.controller;

import com.pgmanagement.pgms.dto.TenantRegistrationDTO;
import com.pgmanagement.pgms.service.TenantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {
    private final TenantService tenantService;

    @Autowired
    public AuthController(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/tenant/login")
    public String tenantLoginPage() {
        return "tenant/login";
    }

    @GetMapping("/admin/login")
    public String adminLoginPage() {
        return "admin/login";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("tenant", new TenantRegistrationDTO());
        return "register";
    }

    @PostMapping("/register")
    public String registerTenant(@ModelAttribute("tenant") TenantRegistrationDTO dto) {
        tenantService.registerTenant(dto);
        return "redirect:/tenant/login";
    }
}
