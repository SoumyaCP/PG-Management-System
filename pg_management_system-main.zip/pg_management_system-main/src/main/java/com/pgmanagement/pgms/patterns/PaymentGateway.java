package com.pgmanagement.pgms.patterns;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class PaymentGateway {
    private static PaymentGateway instance;
    private boolean isInitialized;

    private PaymentGateway() {
        // Private constructor to prevent instantiation
        this.isInitialized = false;
    }

    public static synchronized PaymentGateway getInstance() {
        if (instance == null) {
            instance = new PaymentGateway();
        }
        return instance;
    }

    public void initialize() {
        if (!isInitialized) {
            // Simulate payment gateway initialization
            System.out.println("Initializing Payment Gateway...");
            isInitialized = true;
        }
    }

    public boolean processPayment(BigDecimal amount, String paymentMethod, String description) {
        if (!isInitialized) {
            throw new IllegalStateException("Payment Gateway not initialized");
        }

        // Simulate payment processing
        System.out.println("Processing payment of " + amount + " via " + paymentMethod);
        System.out.println("Description: " + description);
        System.out.println("Timestamp: " + LocalDateTime.now());
        
        // Simulate successful payment
        return true;
    }

    public boolean validatePayment(BigDecimal amount) {
        if (!isInitialized) {
            throw new IllegalStateException("Payment Gateway not initialized");
        }

        // Simulate payment validation
        return amount.compareTo(BigDecimal.ZERO) > 0;
    }
} 