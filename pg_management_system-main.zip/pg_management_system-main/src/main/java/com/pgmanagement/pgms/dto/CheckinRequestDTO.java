package com.pgmanagement.pgms.dto;

import com.pgmanagement.pgms.model.Booking;
import com.pgmanagement.pgms.model.Payment;

public class CheckinRequestDTO {
    private Booking booking;
    private Payment payment;

    public CheckinRequestDTO(Booking booking, Payment payment) {
        this.booking = booking;
        this.payment = payment;
    }

    // Getters and Setters
    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }
} 