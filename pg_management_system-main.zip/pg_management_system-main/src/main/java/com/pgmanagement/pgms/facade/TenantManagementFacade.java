package com.pgmanagement.pgms.facade;

import com.pgmanagement.pgms.dto.TenantRegistrationDTO;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.service.TenantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class TenantManagementFacade {

    private final TenantService tenantService;

    @Autowired
    public TenantManagementFacade(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    public Tenant registerTenant(TenantRegistrationDTO dto) {
        return tenantService.registerTenant(dto);
    }

    public Optional<Tenant> findByUsername(String username) {
        return tenantService.findByUsername(username);
    }

    public void updateTenantProfile(Tenant tenant) {
        tenantService.updateTenantProfile(tenant);
    }
}
