package com.pgmanagement.pgms.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
@Entity
public class Complaint {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "tenant_id", nullable = false)
    private Tenant tenant;

    private String description;
    private LocalDateTime createdAt;
    private String status;
    private String roomNumber;
    private String resolution;
    private LocalDateTime resolvedDateTime;
    private String staffAllocated;

    public Complaint() {}

    public Complaint(Tenant tenant, String description, LocalDateTime createdAt, String status, String roomNumber,
                    String resolution, LocalDateTime resolvedDateTime, String staffAllocated) {
        this.tenant = tenant;
        this.description = description;
        this.createdAt = createdAt;
        this.status = status;
        this.roomNumber = roomNumber;
        this.resolution = resolution;
        this.resolvedDateTime = resolvedDateTime;
        this.staffAllocated = staffAllocated;
    }

    public static class Builder {
        private Tenant tenant;
        private String description;
        private LocalDateTime createdAt;
        private String status;
        private String roomNumber;
        private String resolution;
        private LocalDateTime resolvedDateTime;
        private String staffAllocated;

        public Builder tenant(Tenant tenant) {
            this.tenant = tenant;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder createdAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder roomNumber(String roomNumber) {
            this.roomNumber = roomNumber;
            return this;
        }

        public Builder resolution(String resolution) {
            this.resolution = resolution;
            return this;
        }

        public Builder resolvedDateTime(LocalDateTime resolvedDateTime) {
            this.resolvedDateTime = resolvedDateTime;
            return this;
        }

        public Builder staffAllocated(String staffAllocated) {
            this.staffAllocated = staffAllocated;
            return this;
        }

        public Complaint build() {
            return new Complaint(tenant, description, createdAt, status, roomNumber, resolution, resolvedDateTime, staffAllocated);
        }
    }

    public Long getId() { return id; }
    public Tenant getTenant() { return tenant; }
    public void setTenant(Tenant tenant) { this.tenant = tenant; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public String getResolution() { return resolution; }
    public void setResolution(String resolution) { this.resolution = resolution; }
    public LocalDateTime getResolvedDateTime() { return resolvedDateTime; }
    public void setResolvedDateTime(LocalDateTime resolvedDateTime) { this.resolvedDateTime = resolvedDateTime; }
    public String getStaffAllocated() { return staffAllocated; }
    public void setStaffAllocated(String staffAllocated) { this.staffAllocated = staffAllocated; }
}
