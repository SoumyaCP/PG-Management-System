package com.pgmanagement.pgms.dto;

public class AdminRegistrationDTO {
    private String username = "";
    private String name = "";
    private String password = "";
    private String email = "";

    private AdminRegistrationDTO(Builder builder) {
        this.username = builder.username != null ? builder.username : "";
        this.name = builder.name != null ? builder.name : "";
        this.password = builder.password != null ? builder.password : "";
        this.email = builder.email != null ? builder.email : "";
    }

    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    // Builder Pattern
    public static class Builder {
        private String username = "";
        private String name = "";
        private String password = "";
        private String email = "";

        public Builder username(String username) {
            this.username = username;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public AdminRegistrationDTO build() {
            return new AdminRegistrationDTO(this);
        }
    }
} 