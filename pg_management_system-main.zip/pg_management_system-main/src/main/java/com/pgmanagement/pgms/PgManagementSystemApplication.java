package com.pgmanagement.pgms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgManagementSystemApplication.class, args);
	}

}
