package com.pgmanagement.pgms.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Room number is required")
    @Column(name = "room_number", length = 255)
    private String roomNumber;

    @Column(name = "room_type", length = 255)
    private String roomType = "Single"; // Default and fixed value

    @Column(name = "capacity")
    private Integer capacity = 1; // Default value

    @Column(name = "floor_number", length = 255)
    private String floorNumber;

    @NotNull(message = "Rent amount is required")
    @Positive(message = "Rent amount must be positive")
    @Column(name = "rent_amount", precision = 38, scale = 2)
    private BigDecimal rentAmount;

    @NotNull(message = "Availability status is required")
    @Column(name = "available")
    private Boolean available;

    @Column(name = "rent", precision = 38, scale = 2)
    private BigDecimal rent;

    // Default constructor
    public Room() {
        this.available = true;
        this.capacity = 1;
        this.roomType = "Single";
    }

    // Getters
    public Long getId() { return id; }
    public String getRoomNumber() { return roomNumber; }
    public String getRoomType() { return roomType; }
    public Integer getCapacity() { return capacity; }
    public String getFloorNumber() { return floorNumber; }
    public BigDecimal getRentAmount() { return rentAmount; }
    public Boolean getAvailable() { return available; }
    public BigDecimal getRent() { return rent; }

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public void setFloorNumber(String floorNumber) { this.floorNumber = floorNumber; }
    public void setRentAmount(BigDecimal rentAmount) { 
        this.rentAmount = rentAmount;
        this.rent = rentAmount;
    }
    public void setAvailable(Boolean available) { this.available = available; }
    public void setRent(BigDecimal rent) { this.rent = rent; }

    // Additional method for availability check
    public boolean isAvailable() {
        return available != null && available;
    }
}
