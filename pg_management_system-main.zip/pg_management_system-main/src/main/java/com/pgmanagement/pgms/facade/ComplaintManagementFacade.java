package com.pgmanagement.pgms.facade;

import com.pgmanagement.pgms.dto.ComplaintDTO;
import com.pgmanagement.pgms.model.Complaint;
import com.pgmanagement.pgms.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ComplaintManagementFacade {

    private final ComplaintService complaintService;

    @Autowired
    public ComplaintManagementFacade(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    public List<Complaint> getTenantComplaints(Long tenantId) {
        return complaintService.getTenantComplaints(tenantId);
    }

    public Complaint raiseComplaint(Long tenantId, ComplaintDTO dto) {
        return complaintService.raiseComplaint(tenantId, dto);
    }
}
