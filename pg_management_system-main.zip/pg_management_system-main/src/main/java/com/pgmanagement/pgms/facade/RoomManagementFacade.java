package com.pgmanagement.pgms.facade;

import com.pgmanagement.pgms.dto.RoomDTO;
import com.pgmanagement.pgms.model.Room;
import com.pgmanagement.pgms.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RoomManagementFacade {

    private final RoomService roomService;

    @Autowired
    public RoomManagementFacade(RoomService roomService) {
        this.roomService = roomService;
    }

    public List<RoomDTO> getAvailableRooms() {
        return roomService.getAvailableRooms();
    }

    public List<RoomDTO> getAllRooms() {
        return roomService.getAllRooms();
    }

    public Room addRoom(Room room) {
        return roomService.addRoom(room);
    }

    public void deleteRoom(Long id) {
        roomService.deleteRoom(id);
    }

    // Add other Room management operations as needed
}
