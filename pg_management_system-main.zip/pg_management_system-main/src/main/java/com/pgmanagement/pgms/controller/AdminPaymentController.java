package com.pgmanagement.pgms.controller;

import com.pgmanagement.pgms.model.MonthlyPayment;
import com.pgmanagement.pgms.service.MonthlyPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminPaymentController {

    private final MonthlyPaymentService monthlyPaymentService;

    @Autowired
    public AdminPaymentController(MonthlyPaymentService monthlyPaymentService) {
        this.monthlyPaymentService = monthlyPaymentService;
    }

    @GetMapping("/payments")
    public String viewPayments(Model model) {
        List<MonthlyPayment> payments = monthlyPaymentService.getAllPayments();
        model.addAttribute("payments", payments);
        return "admin/payments";
    }

    @PostMapping("/payments/{id}/approve")
    public String approvePayment(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            monthlyPaymentService.approvePayment(id);
            redirectAttributes.addFlashAttribute("successMessage", "Payment approved successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to approve payment: " + e.getMessage());
        }
        return "redirect:/admin/payments";
    }

    @PostMapping("/payments/{id}/reject")
    public String rejectPayment(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            monthlyPaymentService.rejectPayment(id);
            redirectAttributes.addFlashAttribute("successMessage", "Payment rejected successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to reject payment: " + e.getMessage());
        }
        return "redirect:/admin/payments";
    }
} 