package com.pgmanagement.pgms.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class Owner extends User {
    public Owner() { super(); }
    public Owner(String username, String name, String password, String email) {
        super(username, name, password, email);
    }
}