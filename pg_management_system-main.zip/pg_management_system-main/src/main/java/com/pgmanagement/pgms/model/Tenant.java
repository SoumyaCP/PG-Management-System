package com.pgmanagement.pgms.model;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@DiscriminatorValue("TENANT")
public class Tenant extends User {


    public Tenant() {
        super();
        setRole("TENANT");
    }

    public Tenant(String username, String name, String password, String email, String phone, String address) {
        super(username, name, password, email);
        setPhone(phone);      // inherited from User
        setAddress(address);  // inherited from User
        setRole("TENANT");
    }


    // ✅ Builder Pattern
    public static class Builder {
        private String username;
        private String name;
        private String password;
        private String email;
        private String phone;
        private String address;

        public Builder username(String username) {
            this.username = username;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder phone(String phone) {
            this.phone = phone;
            return this;
        }

        public Builder address(String address) {
            this.address = address;
            return this;
        }

        public Tenant build() {
            return new Tenant(username, name, password, email, phone, address);
        }
    }

    // ✅ equals() and hashCode() override for Hibernate dirty checking
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tenant)) return false;
        if (!super.equals(o)) return false;
        Tenant tenant = (Tenant) o;
        return Objects.equals(getId(), tenant.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getId());
    }
}
