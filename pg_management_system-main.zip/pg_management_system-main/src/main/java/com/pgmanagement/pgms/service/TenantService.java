package com.pgmanagement.pgms.service;

import com.pgmanagement.pgms.dto.TenantRegistrationDTO;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.repository.TenantRepository;
import com.pgmanagement.pgms.builder.TenantBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TenantService {
    private final TenantRepository tenantRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public TenantService(TenantRepository tenantRepository, PasswordEncoder passwordEncoder) {
        this.tenantRepository = tenantRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Tenant registerTenant(TenantRegistrationDTO dto) {
        String encodedPassword = passwordEncoder.encode(dto.getPassword());

        Tenant tenant = new TenantBuilder()
                .withName(dto.getName())
                .withEmail(dto.getEmail())
                .withPhoneNumber(dto.getPhone())
                .withAddress(dto.getAddress())
                .withId(null) // Optional if DB auto-generates ID
                .build();

        tenant.setUsername(dto.getUsername());
        tenant.setPassword(encodedPassword);
        tenant.setRole("TENANT");

        return tenantRepository.save(tenant);
    }

    public Optional<Tenant> findByUsername(String username) {
        return tenantRepository.findByUsername(username);
    }

    
    public void updateTenantProfile(Tenant tenant) {
        // Debugging: Print the tenant before saving
        System.out.println("Saving Tenant: " + tenant);

        tenantRepository.save(tenant);  // Save the tenant
    }

}
