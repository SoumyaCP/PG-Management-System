package com.pgmanagement.pgms.facade;

import com.pgmanagement.pgms.dto.BookingDTO;
import com.pgmanagement.pgms.model.Booking;
import com.pgmanagement.pgms.model.Room;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.repository.BookingRepository;
import com.pgmanagement.pgms.repository.RoomRepository;
import com.pgmanagement.pgms.repository.TenantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class BookingManagementFacade {
    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final TenantRepository tenantRepository;

    @Autowired
    public BookingManagementFacade(
            BookingRepository bookingRepository,
            RoomRepository roomRepository,
            TenantRepository tenantRepository) {
        this.bookingRepository = bookingRepository;
        this.roomRepository = roomRepository;
        this.tenantRepository = tenantRepository;
    }

    public Booking createBooking(BookingDTO bookingDTO) {
        Room room = roomRepository.findById(bookingDTO.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room not found"));
        
        Tenant tenant = tenantRepository.findById(bookingDTO.getTenantId())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));

        if (!room.getAvailable()) {
            throw new RuntimeException("Room is not available");
        }

        Booking booking = new Booking();
        booking.setRoom(room);
        booking.setTenant(tenant);
        booking.setBookingDate(bookingDTO.getBookingDate() != null ? 
                             bookingDTO.getBookingDate() : 
                             LocalDate.now());
        booking.setStatus(bookingDTO.getBookingStatus());
        booking.setActive(true);

        // Mark room as unavailable
        room.setAvailable(false);
        roomRepository.save(room);

        return bookingRepository.save(booking);
    }

    public void checkout(Long tenantId) {
        Booking activeBooking = bookingRepository.findByTenantIdAndActive(tenantId, true)
                .orElseThrow(() -> new RuntimeException("No active booking found"));

        // Mark room as available
        Room room = activeBooking.getRoom();
        room.setAvailable(true);
        roomRepository.save(room);

        // Mark booking as inactive
        activeBooking.setActive(false);
        activeBooking.setStatus("COMPLETED");
        bookingRepository.save(activeBooking);
    }

    public Booking getActiveBooking(Long tenantId) {
        return bookingRepository.findByTenantIdAndActive(tenantId, true)
                .orElseThrow(() -> new RuntimeException("No active booking found for tenant"));
    }

    public Booking updateBooking(Booking booking) {
        // Validate booking exists
        Booking existingBooking = bookingRepository.findById(booking.getId())
            .orElseThrow(() -> new RuntimeException("Booking not found"));
            
        // Validate booking belongs to tenant
        if (!existingBooking.getTenant().getId().equals(booking.getTenant().getId())) {
            throw new RuntimeException("Unauthorized to update this booking");
        }
        
        // Update booking
        existingBooking.setEndDate(booking.getEndDate());
        existingBooking.setStatus(booking.getStatus());
        
        return bookingRepository.save(existingBooking);
    }
    
    // You can add other booking-related operations here like canceling, updating, etc.
}
