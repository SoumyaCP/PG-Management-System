package com.pgmanagement.pgms.model;
 
public enum CheckoutStatus {
    PENDING,
    APPROVED,
    REJECTED
} 