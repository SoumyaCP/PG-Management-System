package com.pgmanagement.pgms.dto;
import java.time.LocalDateTime;

public class ComplaintDTO {
    private Long id;
    private Long tenantId;
    private String complaintType;
    private String description;
    private String roomNumber;
    private LocalDateTime raisedDateTime;
    private String status;
    private String resolution;
    private LocalDateTime resolvedDateTime;
    
    // Default constructor
    public ComplaintDTO() {
    }
    
    // Parameterized constructor
    public ComplaintDTO(Long id, Long tenantId, String complaintType, String description, String roomNumber, 
                      LocalDateTime raisedDateTime, String status, String resolution, 
                      LocalDateTime resolvedDateTime) {
        this.id = id;
        this.tenantId = tenantId;
        this.complaintType = complaintType;
        this.description = description;
        this.roomNumber = roomNumber;
        this.raisedDateTime = raisedDateTime;
        this.status = status;
        this.resolution = resolution;
        this.resolvedDateTime = resolvedDateTime;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTenantId() {
        return tenantId;
    }

    public void setTenantId(Long tenantId) {
        this.tenantId = tenantId;
    }

    public String getComplaintType() {
        return complaintType;
    }

    public void setComplaintType(String complaintType) {
        this.complaintType = complaintType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public LocalDateTime getRaisedDateTime() {
        return raisedDateTime;
    }

    public void setRaisedDateTime(LocalDateTime raisedDateTime) {
        this.raisedDateTime = raisedDateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public LocalDateTime getResolvedDateTime() {
        return resolvedDateTime;
    }

    public void setResolvedDateTime(LocalDateTime resolvedDateTime) {
        this.resolvedDateTime = resolvedDateTime;
    }
}