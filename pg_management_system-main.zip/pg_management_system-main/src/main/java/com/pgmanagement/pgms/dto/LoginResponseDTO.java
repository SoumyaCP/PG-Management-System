// LoginResponseDTO.java
package com.pgmanagement.pgms.dto;
public class LoginResponseDTO {
    private Long userId;
    private String username;
    private String userType;
    private String token;
    private String message;
    
    // Default constructor
    public LoginResponseDTO() {
    }
    
    // Parameterized constructor
    public LoginResponseDTO(Long userId, String username, String userType, String token, String message) {
        this.userId = userId;
        this.username = username;
        this.userType = userType;
        this.token = token;
        this.message = message;
    }
    
    // Getters and Setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}