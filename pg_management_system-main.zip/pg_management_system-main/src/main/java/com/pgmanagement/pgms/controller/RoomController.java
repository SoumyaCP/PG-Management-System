package com.pgmanagement.pgms.controller;
import com.pgmanagement.pgms.model.Room;

import com.pgmanagement.pgms.dto.RoomDTO;
import com.pgmanagement.pgms.facade.RoomManagementFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/rooms")
public class RoomController {

    private final RoomManagementFacade roomManagementFacade;

    @Autowired
    public RoomController(RoomManagementFacade roomManagementFacade) {
        this.roomManagementFacade = roomManagementFacade;
    }

    @GetMapping("/available")
    public List<RoomDTO> getAvailableRooms() {
        return roomManagementFacade.getAvailableRooms();
    }

    @PostMapping("/add")
    public RoomDTO addRoom(@RequestBody RoomDTO roomDTO) {
        Room room = new Room();
        // Add properties from roomDTO to room, e.g., room.setRoomNumber(roomDTO.getRoomNumber());
        // Then add room via facade
        roomManagementFacade.addRoom(room);
        return roomDTO; // Optionally return updated RoomDTO
    }
}
