package com.pgmanagement.pgms.service;

import com.pgmanagement.pgms.model.FoodMenu;
import com.pgmanagement.pgms.repository.FoodMenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.time.DayOfWeek;
import java.time.LocalDate;

@Service
public class FoodMenuService {

    @Autowired
    private FoodMenuRepository foodMenuRepository;

    public List<FoodMenu> getAllMenus() {
        return foodMenuRepository.findAll();
    }

    public List<FoodMenu> getActiveMenus() {
        return foodMenuRepository.findByIsActiveTrue();
    }

    public FoodMenu getTodayMenu() {
        String today = LocalDate.now().getDayOfWeek().toString();
        return foodMenuRepository.findByDayOfWeekAndIsActiveTrue(today);
    }

    public FoodMenu getMenuForDay(String dayOfWeek) {
        return foodMenuRepository.findByDayOfWeekAndIsActiveTrue(dayOfWeek);
    }

    public FoodMenu saveMenu(FoodMenu menu) {
        // Deactivate any existing menu for the same day
        FoodMenu existingMenu = foodMenuRepository.findByDayOfWeekAndIsActiveTrue(menu.getDayOfWeek());
        if (existingMenu != null) {
            existingMenu.setIsActive(false);
            foodMenuRepository.save(existingMenu);
        }
        
        // Set the new menu as active
        menu.setIsActive(true);
        return foodMenuRepository.save(menu);
    }

    public void deleteMenu(Long id) {
        foodMenuRepository.deleteById(id);
    }
} 