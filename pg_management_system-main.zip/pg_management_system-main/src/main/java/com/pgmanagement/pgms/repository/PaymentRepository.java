package com.pgmanagement.pgms.repository;

import com.pgmanagement.pgms.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Payment findByBookingId(Long bookingId);
    List<Payment> findByStatus(String status);
    
    @Query("SELECT p FROM Payment p WHERE p.booking.tenant.id = :tenantId ORDER BY p.createdAt DESC")
    List<Payment> findByTenantId(Long tenantId);
} 