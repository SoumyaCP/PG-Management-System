package com.pgmanagement.pgms.service;

import com.pgmanagement.pgms.dto.ComplaintDTO;
import com.pgmanagement.pgms.model.Complaint;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.model.Booking;
import com.pgmanagement.pgms.model.Payment;
import com.pgmanagement.pgms.repository.ComplaintRepository;
import com.pgmanagement.pgms.repository.TenantRepository;
import com.pgmanagement.pgms.repository.BookingRepository;
import com.pgmanagement.pgms.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Arrays;

@Service
public class ComplaintService {
    private final ComplaintRepository complaintRepository;
    private final TenantRepository tenantRepository;
    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;

    // List of maintenance staff
    private final List<String> maintenanceStaff = Arrays.asList(
        "John Smith", "Emma Wilson", "Michael Brown", "Sarah Davis",
        "David Miller", "Lisa Anderson", "James Wilson", "Jennifer Taylor",
        "Robert Johnson", "Mary Williams"
    );

    @Autowired
    public ComplaintService(
            ComplaintRepository complaintRepository, 
            TenantRepository tenantRepository,
            BookingRepository bookingRepository,
            PaymentRepository paymentRepository) {
        this.complaintRepository = complaintRepository;
        this.tenantRepository = tenantRepository;
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
    }

    public List<String> getAllMaintenanceStaff() {
        return maintenanceStaff;
    }

    public Complaint allocateStaff(Long complaintId, String staffName) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        if (!"OPEN".equals(complaint.getStatus())) {
            throw new RuntimeException("Can only allocate staff to OPEN complaints");
        }

        complaint.setStaffAllocated(staffName);
        complaint.setStatus("ONGOING");
        return complaintRepository.save(complaint);
    }

    public Complaint raiseComplaint(Long tenantId, ComplaintDTO dto) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new RuntimeException("Tenant not found"));

        // Check for active booking
        Booking activeBooking = bookingRepository.findByTenantIdAndActive(tenantId, true)
                .orElseThrow(() -> new RuntimeException("No active booking found for tenant"));

        // Check for approved payment
        Payment payment = paymentRepository.findByBookingId(activeBooking.getId());
        if (payment == null || !"APPROVED".equals(payment.getStatus())) {
            throw new RuntimeException("Cannot raise complaint - Payment not approved");
        }

        Complaint complaint = new Complaint();
        complaint.setTenant(tenant);
        complaint.setDescription(dto.getDescription());
        complaint.setRoomNumber(dto.getRoomNumber());
        complaint.setCreatedAt(LocalDateTime.now());
        complaint.setStatus("OPEN");

        return complaintRepository.save(complaint);
    }

    public List<Complaint> getTenantComplaints(Long tenantId) {
        return complaintRepository.findByTenantId(tenantId);
    }

    // Admin methods
    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }

    public Complaint resolveComplaint(Long complaintId, String resolution) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        if ("RESOLVED".equals(complaint.getStatus())) {
            throw new RuntimeException("Complaint is already resolved");
        }

        complaint.setStatus("RESOLVED");
        complaint.setResolution(resolution);
        complaint.setResolvedDateTime(LocalDateTime.now());

        return complaintRepository.save(complaint);
    }
}
