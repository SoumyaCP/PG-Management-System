package com.pgmanagement.pgms.dto;

import java.math.BigDecimal;

public class RoomDTO {
    private Long id;
    private String roomNumber;
    private String roomType = "Single";
    private Integer capacity = 1;
    private String floorNumber;
    private BigDecimal rentAmount;
    private Boolean available;
    private BigDecimal rent;

    // Private constructor
    private RoomDTO(Builder builder) {
        this.id = builder.id;
        this.roomNumber = builder.roomNumber;
        this.roomType = "Single"; // Always Single
        this.capacity = 1; // Always 1
        this.floorNumber = builder.floorNumber;
        this.rentAmount = builder.rentAmount;
        this.available = builder.available;
        this.rent = builder.rentAmount;
    }

    // Getters
    public Long getId() { return id; }
    public String getRoomNumber() { return roomNumber; }
    public String getRoomType() { return roomType; }
    public Integer getCapacity() { return capacity; }
    public String getFloorNumber() { return floorNumber; }
    public BigDecimal getRentAmount() { return rentAmount; }
    public Boolean getAvailable() { return available; }
    public BigDecimal getRent() { return rent; }

    // Builder Class
    public static class Builder {
        private Long id;
        private String roomNumber;
        private String floorNumber;
        private BigDecimal rentAmount;
        private Boolean available;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder roomNumber(String roomNumber) {
            this.roomNumber = roomNumber;
            return this;
        }

        public Builder floorNumber(String floorNumber) {
            this.floorNumber = floorNumber;
            return this;
        }

        public Builder rentAmount(BigDecimal rentAmount) {
            this.rentAmount = rentAmount;
            return this;
        }

        public Builder available(Boolean available) {
            this.available = available;
            return this;
        }

        public RoomDTO build() {
            return new RoomDTO(this);
        }
    }
}
