package com.pgmanagement.pgms.controller;

import com.pgmanagement.pgms.model.FoodMenu;
import com.pgmanagement.pgms.service.FoodMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/tenant")
public class TenantFoodMenuController {

    @Autowired
    private FoodMenuService foodMenuService;

    @GetMapping("/food-menu")
    public String viewFoodMenu(Model model) {
        List<FoodMenu> activeMenus = foodMenuService.getActiveMenus();
        FoodMenu todayMenu = foodMenuService.getTodayMenu();
        model.addAttribute("menus", activeMenus);
        model.addAttribute("todayMenu", todayMenu);
        return "tenant/food-menu";
    }
} 