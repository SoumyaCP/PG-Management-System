package com.pgmanagement.pgms.service;

import com.pgmanagement.pgms.dto.BookingDTO;
import com.pgmanagement.pgms.model.Booking;
import com.pgmanagement.pgms.model.Room;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.repository.BookingRepository;
import com.pgmanagement.pgms.repository.RoomRepository;
import com.pgmanagement.pgms.repository.TenantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final TenantRepository tenantRepository;

    @Autowired
    public BookingService(
            BookingRepository bookingRepository,
            RoomRepository roomRepository,
            TenantRepository tenantRepository) {
        this.bookingRepository = bookingRepository;
        this.roomRepository = roomRepository;
        this.tenantRepository = tenantRepository;
    }

    public Booking createBooking(BookingDTO bookingDTO) {
        Room room = roomRepository.findById(bookingDTO.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room not found"));

        Tenant tenant = tenantRepository.findById(bookingDTO.getTenantId())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));

        if (!room.isAvailable()) {
            throw new RuntimeException("Room is not available for booking.");
        }

        Booking booking = new Booking.Builder()
                .room(room)
                .tenant(tenant)
                .startDate(LocalDate.now())
                .endDate(bookingDTO.getEndDate())
                .active(true)
                .paymentStatus("Pending")
                .build();

        room.setAvailable(false);
        roomRepository.save(room);

        return bookingRepository.save(booking);
    }

    public Booking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
    }

    public Booking updateBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}
