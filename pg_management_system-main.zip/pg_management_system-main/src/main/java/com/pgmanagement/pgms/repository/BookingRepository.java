package com.pgmanagement.pgms.repository;

import com.pgmanagement.pgms.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByTenantId(Long tenantId);
    Optional<Booking> findByTenantIdAndActive(Long tenantId, boolean active);
}