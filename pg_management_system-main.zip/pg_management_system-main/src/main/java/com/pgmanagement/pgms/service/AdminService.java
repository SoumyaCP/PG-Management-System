package com.pgmanagement.pgms.service;

import com.pgmanagement.pgms.dto.AdminRegistrationDTO;
import com.pgmanagement.pgms.dto.AdminProfileUpdateDTO;
import com.pgmanagement.pgms.model.User;
import com.pgmanagement.pgms.patterns.UserFactory;
import com.pgmanagement.pgms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserFactory userFactory;

    @Autowired
    public AdminService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            UserFactory userFactory) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.userFactory = userFactory;
    }

    public boolean adminExists() {
        return userRepository.existsByRole("ADMIN");
    }

    public User registerAdmin(AdminRegistrationDTO dto) throws IllegalArgumentException {
        // Check if admin already exists
        if (adminExists()) {
            throw new IllegalArgumentException("Admin already exists. Only one admin is allowed in the system.");
        }

        // Check if username already exists
        if (userRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException("Username already exists. Please choose a different username.");
        }

        // Check if email already exists
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already exists. Please use a different email address.");
        }

        // Create admin user using factory pattern
        User admin = userFactory.createUser(
            "ADMIN",
            dto.getUsername(),
            dto.getName(),
            passwordEncoder.encode(dto.getPassword()),
            dto.getEmail()
        );

        // Save the admin user
        return userRepository.save(admin);
    }

    public User getAdminByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found"));
    }

    public User updateAdminProfile(String username, AdminProfileUpdateDTO updateDTO) {
        User admin = getAdminByUsername(username);

        // Verify current password if provided
        if (updateDTO.getCurrentPassword() != null && !updateDTO.getCurrentPassword().isEmpty()) {
            if (!passwordEncoder.matches(updateDTO.getCurrentPassword(), admin.getPassword())) {
                throw new IllegalArgumentException("Current password is incorrect");
            }
        }

        // Update fields
        admin.setName(updateDTO.getName());
        
        // Check if email is being changed and if it's already in use
        if (!admin.getEmail().equals(updateDTO.getEmail())) {
            if (userRepository.findByEmail(updateDTO.getEmail()).isPresent()) {
                throw new IllegalArgumentException("Email is already in use");
            }
            admin.setEmail(updateDTO.getEmail());
        }

        // Update password if new password is provided
        if (updateDTO.getNewPassword() != null && !updateDTO.getNewPassword().isEmpty()) {
            admin.setPassword(passwordEncoder.encode(updateDTO.getNewPassword()));
        }

        return userRepository.save(admin);
    }
} 