package com.pgmanagement.pgms.dto;

import java.time.LocalDate;
import java.math.BigDecimal;

public class BookingDTO {
    private Long id;
    private Long tenantId;
    private Long roomId;
    private LocalDate bookingDate;
    private LocalDate checkInDate;
    private LocalDate expectedCheckoutDate;
    private BigDecimal securityDeposit;
    private String paymentStatus;
    private String bookingStatus;
    private boolean active;

    // Default constructor
    public BookingDTO() {}

    // Parameterized constructor
    public BookingDTO(Long id, Long tenantId, Long roomId, LocalDate bookingDate, 
                      LocalDate checkInDate, LocalDate expectedCheckoutDate, 
                      BigDecimal securityDeposit, String paymentStatus, String bookingStatus) {
        this.id = id;
        this.tenantId = tenantId;
        this.roomId = roomId;
        this.bookingDate = bookingDate;
        this.checkInDate = checkInDate;
        this.expectedCheckoutDate = expectedCheckoutDate;
        this.securityDeposit = securityDeposit;
        this.paymentStatus = paymentStatus;
        this.bookingStatus = bookingStatus;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getTenantId() { return tenantId; }
    public void setTenantId(Long tenantId) { this.tenantId = tenantId; }

    public Long getRoomId() { return roomId; }
    public void setRoomId(Long roomId) { this.roomId = roomId; }

    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) { this.bookingDate = bookingDate; }

    public LocalDate getCheckInDate() { return checkInDate; }
    public void setCheckInDate(LocalDate checkInDate) { this.checkInDate = checkInDate; }

    public LocalDate getEndDate() { return expectedCheckoutDate; } // ✅ Updated to match BookingService
    public void setEndDate(LocalDate expectedCheckoutDate) { this.expectedCheckoutDate = expectedCheckoutDate; }

    public BigDecimal getSecurityDeposit() { return securityDeposit; }
    public void setSecurityDeposit(BigDecimal securityDeposit) { this.securityDeposit = securityDeposit; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getBookingStatus() { return bookingStatus; }
    public void setBookingStatus(String bookingStatus) { this.bookingStatus = bookingStatus; }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
