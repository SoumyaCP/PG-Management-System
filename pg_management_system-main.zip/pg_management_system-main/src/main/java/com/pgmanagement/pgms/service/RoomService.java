package com.pgmanagement.pgms.service;

import com.pgmanagement.pgms.dto.RoomDTO;
import com.pgmanagement.pgms.model.Room;
import com.pgmanagement.pgms.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    public List<RoomDTO> getAvailableRooms() {
        List<Room> availableRooms = roomRepository.findByAvailableTrue();
        return availableRooms.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<RoomDTO> getAllRooms() {
        List<Room> allRooms = roomRepository.findAll();
        return allRooms.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public Room addRoom(Room room) {
        return roomRepository.save(room);
    }

    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }

    public Room getRoomById(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Room not found"));
    }

    private RoomDTO convertToDTO(Room room) {
        return new RoomDTO.Builder()
                .id(room.getId())
                .roomNumber(room.getRoomNumber())
                .floorNumber(room.getFloorNumber())
                .rentAmount(room.getRentAmount())
                .available(room.getAvailable())
                .build();
    }
}
