package com.pgmanagement.pgms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.DiscriminatorValue;

@Entity
@DiscriminatorValue("ADMIN")
public class Admin extends User {
    
    public Admin() {
        super();
        this.setRole("ADMIN");
    }

    public Admin(String username, String name, String password, String email) {
        super(username, name, password, email);
        this.setRole("ADMIN");
    }
} 