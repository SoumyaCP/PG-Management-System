package com.pgmanagement.pgms.controller;

import com.pgmanagement.pgms.dto.BookingDTO;
import com.pgmanagement.pgms.dto.ComplaintDTO;
import com.pgmanagement.pgms.dto.RoomDTO;
import com.pgmanagement.pgms.facade.BookingManagementFacade;
import com.pgmanagement.pgms.facade.ComplaintManagementFacade;
import com.pgmanagement.pgms.facade.RoomManagementFacade;
import com.pgmanagement.pgms.facade.TenantManagementFacade;
import com.pgmanagement.pgms.model.Booking;
import com.pgmanagement.pgms.model.Payment;
import com.pgmanagement.pgms.model.Room;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.model.MonthlyPayment;
import com.pgmanagement.pgms.model.CheckoutRequest;
import com.pgmanagement.pgms.model.CheckoutStatus;
import com.pgmanagement.pgms.service.MonthlyPaymentService;
import com.pgmanagement.pgms.service.PaymentService;
import com.pgmanagement.pgms.service.RoomService;
import com.pgmanagement.pgms.repository.CheckoutRequestRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.security.Principal;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/tenant")
public class TenantController {

    private final RoomManagementFacade roomManagementFacade;
    private final BookingManagementFacade bookingManagementFacade;
    private final ComplaintManagementFacade complaintManagementFacade;
    private final TenantManagementFacade tenantManagementFacade;
    private final PaymentService paymentService;
    private final MonthlyPaymentService monthlyPaymentService;
    private final RoomService roomService;
    private final CheckoutRequestRepository checkoutRequestRepository;

    @Autowired
    public TenantController(
            RoomManagementFacade roomManagementFacade,
            BookingManagementFacade bookingManagementFacade,
            ComplaintManagementFacade complaintManagementFacade,
            TenantManagementFacade tenantManagementFacade,
            PaymentService paymentService,
            MonthlyPaymentService monthlyPaymentService,
            RoomService roomService,
            CheckoutRequestRepository checkoutRequestRepository) {
        this.roomManagementFacade = roomManagementFacade;
        this.bookingManagementFacade = bookingManagementFacade;
        this.complaintManagementFacade = complaintManagementFacade;
        this.tenantManagementFacade = tenantManagementFacade;
        this.paymentService = paymentService;
        this.monthlyPaymentService = monthlyPaymentService;
        this.roomService = roomService;
        this.checkoutRequestRepository = checkoutRequestRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal User user, Model model) {
        model.addAttribute("username", user.getUsername());
        return "tenant/dashboard";
    }

    @GetMapping("/rooms")
    public String viewAvailableRooms(Model model) {
        model.addAttribute("rooms", roomManagementFacade.getAvailableRooms());
        return "tenant/rooms";
    }

    @GetMapping("/book/{id}")
    public String bookRoom(@PathVariable Long id, @AuthenticationPrincipal User user, Model model) {
        // Get the room details
        Room room = roomService.getRoomById(id);
        if (room == null || !room.getAvailable()) {
            return "redirect:/tenant/rooms?error=Room not available";
        }

        // Create booking
        Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));

        BookingDTO bookingDTO = new BookingDTO();
        bookingDTO.setRoomId(id);
        bookingDTO.setTenantId(tenant.getId());
        bookingDTO.setBookingDate(LocalDate.now());
        bookingDTO.setPaymentStatus("PENDING");
        bookingDTO.setBookingStatus("PENDING");

        Booking booking = bookingManagementFacade.createBooking(bookingDTO);

        // Create payment with PENDING status
        Payment payment = paymentService.createPayment(booking, room.getRentAmount());

        // Add attributes for payment page
        model.addAttribute("room", room);
        model.addAttribute("booking", booking);
        model.addAttribute("payment", payment);

        return "tenant/payment";
    }

    @PostMapping("/payment/process")
    public String processPayment(
            @RequestParam Long bookingId,
            @RequestParam BigDecimal amount,
            @RequestParam String paymentMethod,
            @AuthenticationPrincipal User user) {
        
        Payment payment = paymentService.getPaymentByBookingId(bookingId);
        if (payment == null) {
            return "redirect:/tenant/rooms?error=Payment not found";
        }

        // In a real application, you would integrate with a payment gateway here
        // For now, we'll just update the status
        payment.setPaymentMethod(paymentMethod);
        payment.setStatus("PENDING");
        paymentService.updatePaymentStatus(payment.getId(), "PENDING");

        return "redirect:/tenant/dashboard?message=Payment is being processed";
    }

    @GetMapping("/complaints")
    public String viewComplaints(Model model, @AuthenticationPrincipal User user) {
        Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));
        model.addAttribute("complaints", complaintManagementFacade.getTenantComplaints(tenant.getId()));
        return "tenant/complaints";
    }

    @GetMapping("/complaint/new")
    public String newComplaintForm(Model model, @AuthenticationPrincipal User user) {
        try {
            Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                    .orElseThrow(() -> new RuntimeException("Tenant not found"));
            
            // Get active booking to fetch room number
            Booking activeBooking = bookingManagementFacade.getActiveBooking(tenant.getId());
            
            ComplaintDTO complaintDTO = new ComplaintDTO();
            complaintDTO.setRoomNumber(activeBooking.getRoom().getRoomNumber());
            model.addAttribute("complaint", complaintDTO);
            model.addAttribute("roomNumber", activeBooking.getRoom().getRoomNumber());
            
        return "tenant/newComplaint";
        } catch (RuntimeException e) {
            return "redirect:/tenant/dashboard?error=" + e.getMessage();
        }
    }

    @PostMapping("/complaint/new")
    public String raiseComplaint(@ModelAttribute ComplaintDTO dto, @AuthenticationPrincipal User user, Model model) {
        try {
            Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                    .orElseThrow(() -> new RuntimeException("Tenant not found"));
            complaintManagementFacade.raiseComplaint(tenant.getId(), dto);
            return "redirect:/tenant/complaints?success=Complaint submitted successfully";
        } catch (RuntimeException e) {
            // Add error message to model and return to form
            model.addAttribute("complaint", dto);
            model.addAttribute("error", e.getMessage());
            return "tenant/newComplaint";
        }
    }

    @PostMapping("/checkout")
    public String checkout(@AuthenticationPrincipal User user) {
        Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));
        bookingManagementFacade.checkout(tenant.getId());
        return "redirect:/tenant/dashboard";
    }

    // ---------------- PROFILE MANAGEMENT ----------------

    @GetMapping("/profile")
    public String viewProfile(@AuthenticationPrincipal User user, Model model) {
        Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));
        model.addAttribute("tenant", tenant);  // Add tenant details to the model
        return "tenant/tenantprofile";  // Template to view the profile
    }

    @GetMapping("/profile/edit")
    public String editProfileForm(@AuthenticationPrincipal User user, Model model) {
        Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));
        model.addAttribute("tenant", tenant);  // Add tenant details to the form for editing
        return "tenant/editProfile";  // Template to edit the profile
    }

    @PostMapping("/profile/edit")
    public String updateProfile(@ModelAttribute("tenant") Tenant updatedTenant, @AuthenticationPrincipal User user) {
    // Debugging: Check what the received tenant looks like
        System.out.println("Received Tenant: " + updatedTenant);

        Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));

        // Debugging: Check what the current tenant looks like before updating
        System.out.println("Current Tenant: " + tenant);

        tenant.setName(updatedTenant.getName());
        tenant.setEmail(updatedTenant.getEmail());
        tenant.setPhone(updatedTenant.getPhone());
        tenant.setAddress(updatedTenant.getAddress());
        System.out.println("UpdatedTenant name: " + updatedTenant.getName());
        System.out.println("UpdatedTenant phone: " + updatedTenant.getPhone());
        System.out.println("UpdatedTenant address: " + updatedTenant.getAddress());


        // Debugging: Check if values are being set correctly
        System.out.println("Updated Tenant: " + tenant);

        tenantManagementFacade.updateTenantProfile(tenant);  // Save the updated tenant

        return "redirect:/tenant/profile?success";  // Redirect to profile page after update
    }

    @GetMapping("/payments")
    public String viewPayments(@AuthenticationPrincipal User user, Model model) {
        Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));
        
        List<Payment> payments = paymentService.getPaymentsByTenant(tenant.getId());
        model.addAttribute("payments", payments);
        return "tenant/payments";
    }

    @GetMapping("/monthly-payment")
    public String showMonthlyPaymentForm(Model model, Principal principal) {
        try {
            Long tenantId = getTenantId(principal);
            String currentMonth = monthlyPaymentService.getCurrentMonth();
            
            // Check if tenant can make payment for this month
            boolean canMakePayment = monthlyPaymentService.canMakePaymentForMonth(tenantId, currentMonth);
            model.addAttribute("canMakePayment", canMakePayment);
            
            // Get all payments for current month to show history
            List<MonthlyPayment> monthPayments = monthlyPaymentService.findByTenantIdAndMonth(tenantId, currentMonth);
            model.addAttribute("monthlyPayments", monthPayments);
            
            // Check if there's a rejected payment
            boolean hasRejectedPayment = monthPayments.stream()
                    .anyMatch(payment -> "REJECTED".equals(payment.getStatus()));
            model.addAttribute("rejectedPayment", hasRejectedPayment);
            
            model.addAttribute("currentMonth", currentMonth);
            return "tenant/monthlyPayment";
        } catch (Exception e) {
            return "redirect:/tenant/dashboard?error=" + e.getMessage();
        }
    }

    @PostMapping("/monthly-payment")
    public String processMonthlyPayment(
            @RequestParam BigDecimal amount,
            @RequestParam String month,
            @RequestParam String paymentMethod,
            @AuthenticationPrincipal User user) {
        try {
            Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                    .orElseThrow(() -> new RuntimeException("Tenant not found"));
            
            monthlyPaymentService.makePayment(tenant.getId(), amount, month, paymentMethod);
            return "redirect:/tenant/monthly-payments?success=Payment successful";
        } catch (RuntimeException e) {
            return "redirect:/tenant/monthly-payment?error=" + e.getMessage();
        }
    }

    @GetMapping("/monthly-payments")
    public String viewMonthlyPayments(Model model, @AuthenticationPrincipal User user) {
        try {
            Tenant tenant = tenantManagementFacade.findByUsername(user.getUsername())
                    .orElseThrow(() -> new RuntimeException("Tenant not found"));
            
            model.addAttribute("payments", monthlyPaymentService.getTenantPayments(tenant.getId()));
            return "tenant/monthlyPayments";
        } catch (RuntimeException e) {
            return "redirect:/tenant/dashboard?error=" + e.getMessage();
        }
    }

    @GetMapping("/checkout/request")
    public String showCheckoutRequestForm(Model model, Principal principal) {
        try {
            Long tenantId = getTenantId(principal);
            Booking activeBooking = bookingManagementFacade.getActiveBooking(tenantId);
            
            model.addAttribute("booking", activeBooking);
            
            return "tenant/checkoutRequest";
        } catch (Exception e) {
            return "redirect:/tenant/dashboard?error=" + e.getMessage();
        }
    }

    @PostMapping("/checkout/request")
    public String processCheckoutRequest(
            @RequestParam Long bookingId,
            @RequestParam String roomNumber,
            @RequestParam LocalDate checkoutDate,
            @RequestParam String reason,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        try {
            Long tenantId = getTenantId(principal);
            Booking activeBooking = bookingManagementFacade.getActiveBooking(tenantId);
            
            // Validate booking ID
            if (!activeBooking.getId().equals(bookingId)) {
                throw new RuntimeException("Invalid booking");
            }
            
            // Validate room number
            if (!activeBooking.getRoom().getRoomNumber().equals(roomNumber)) {
                throw new RuntimeException("Invalid room number");
            }
            
            // Validate checkout date
            if (checkoutDate.isBefore(LocalDate.now().plusDays(1))) {
                throw new RuntimeException("Checkout date must be at least one day in the future");
            }
            
            // Create checkout request
            CheckoutRequest request = new CheckoutRequest();
            request.setBooking(activeBooking);
            request.setCheckoutDate(checkoutDate);
            request.setReason(reason);
            checkoutRequestRepository.save(request);
            
            redirectAttributes.addFlashAttribute("success", "Checkout request submitted successfully");
            return "redirect:/tenant/dashboard";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/tenant/checkout/request";
        }
    }

    @GetMapping("/checkout/requests")
    public String viewCheckoutRequests(Model model, Principal principal) {
        try {
            Long tenantId = getTenantId(principal);
            Booking activeBooking = bookingManagementFacade.getActiveBooking(tenantId);
            
            // Get all checkout requests for the tenant's active booking
            List<CheckoutRequest> requests = checkoutRequestRepository.findByBookingId(activeBooking.getId());
            model.addAttribute("requests", requests);
            
            // Get pending requests to control whether tenant can create new request
            List<CheckoutRequest> pendingRequests = requests.stream()
                .filter(r -> r.getStatus() == CheckoutStatus.PENDING)
                .collect(Collectors.toList());
            model.addAttribute("pendingRequests", pendingRequests);
            
            return "tenant/checkoutRequests";
        } catch (Exception e) {
            return "redirect:/tenant/dashboard?error=" + e.getMessage();
        }
    }

    private Long getTenantId(Principal principal) {
        Tenant tenant = tenantManagementFacade.findByUsername(principal.getName())
                .orElseThrow(() -> new RuntimeException("Tenant not found"));
        return tenant.getId();
    }

}
