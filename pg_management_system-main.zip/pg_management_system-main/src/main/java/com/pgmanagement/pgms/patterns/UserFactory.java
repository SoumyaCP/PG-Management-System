package com.pgmanagement.pgms.patterns;

import com.pgmanagement.pgms.model.Admin;
import com.pgmanagement.pgms.model.Owner;
import com.pgmanagement.pgms.model.Staff;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.model.User;
import org.springframework.stereotype.Component;

@Component
public class UserFactory {
    public User createUser(String role, String username, String name, String password, String email) {  
        switch (role.toUpperCase()) {
            case "TENANT":
                return new Tenant(username, name, password, email, "", "");
            case "ADMIN":
                return new Admin(username, name, password, email);
            default:
                throw new IllegalArgumentException("Invalid user role: " + role);
        }
    }
}
