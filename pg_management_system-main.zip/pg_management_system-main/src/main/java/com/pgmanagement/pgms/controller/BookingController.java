package com.pgmanagement.pgms.controller;

import com.pgmanagement.pgms.dto.BookingDTO;
import com.pgmanagement.pgms.facade.BookingManagementFacade;
import com.pgmanagement.pgms.model.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bookings")
public class BookingController {

    private final BookingManagementFacade bookingManagementFacade;

    @Autowired
    public BookingController(BookingManagementFacade bookingManagementFacade) {
        this.bookingManagementFacade = bookingManagementFacade;
    }

    @PostMapping("/create")
    public Booking createBooking(@RequestBody BookingDTO bookingDTO) {
        return bookingManagementFacade.createBooking(bookingDTO);
    }

    // You can add more booking-related methods, like canceling or listing bookings
}
