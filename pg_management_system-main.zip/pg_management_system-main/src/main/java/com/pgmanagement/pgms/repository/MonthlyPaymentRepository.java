package com.pgmanagement.pgms.repository;

import com.pgmanagement.pgms.model.MonthlyPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MonthlyPaymentRepository extends JpaRepository<MonthlyPayment, Long> {
    List<MonthlyPayment> findByTenantId(Long tenantId);
    boolean existsByTenantIdAndMonth(Long tenantId, String month);
    List<MonthlyPayment> findByTenantIdAndStatus(Long tenantId, String status);
    boolean existsByTenantIdAndMonthAndStatusIn(Long tenantId, String month, List<String> statuses);
    List<MonthlyPayment> findByTenantIdAndMonth(Long tenantId, String month);
} 