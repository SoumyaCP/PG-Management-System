package com.pgmanagement.pgms.service.validation;

public interface ValidationStrategy {
    boolean validate(String value);
    String getErrorMessage();
} 