package com.pgmanagement.pgms.controller;

import com.pgmanagement.pgms.dto.AdminRegistrationDTO;
import com.pgmanagement.pgms.dto.AdminProfileUpdateDTO;
import com.pgmanagement.pgms.dto.RoomDTO;
import com.pgmanagement.pgms.dto.CheckinRequestDTO;
import com.pgmanagement.pgms.facade.RoomManagementFacade;
import com.pgmanagement.pgms.model.User;
import com.pgmanagement.pgms.model.Room;
import com.pgmanagement.pgms.model.Booking;
import com.pgmanagement.pgms.model.Payment;
import com.pgmanagement.pgms.model.CheckoutRequest;
import com.pgmanagement.pgms.model.CheckoutStatus;
import com.pgmanagement.pgms.repository.CheckoutRequestRepository;
import com.pgmanagement.pgms.repository.BookingRepository;
import com.pgmanagement.pgms.repository.RoomRepository;
import com.pgmanagement.pgms.service.AdminService;
import com.pgmanagement.pgms.service.BookingService;
import com.pgmanagement.pgms.service.PaymentService;
import com.pgmanagement.pgms.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {
    
    private final AdminService adminService;
    private final RoomManagementFacade roomManagementFacade;
    private final PaymentService paymentService;
    private final BookingService bookingService;
    private final ComplaintService complaintService;

    @Autowired
    private CheckoutRequestRepository checkoutRequestRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    public AdminController(
            AdminService adminService, 
            RoomManagementFacade roomManagementFacade,
            PaymentService paymentService,
            BookingService bookingService,
            ComplaintService complaintService) {
        this.adminService = adminService;
        this.roomManagementFacade = roomManagementFacade;
        this.paymentService = paymentService;
        this.bookingService = bookingService;
        this.complaintService = complaintService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        model.addAttribute("username", userDetails.getUsername());
        return "admin/dashboard";
    }

    @GetMapping("/checkin-requests")
    public String viewCheckinRequests(Model model) {
        // Get all pending payments
        List<Payment> pendingPayments = paymentService.getPendingPayments();
        List<CheckinRequestDTO> checkinRequests = new ArrayList<>();

        // Create DTOs combining payment and booking information
        for (Payment payment : pendingPayments) {
            Booking booking = payment.getBooking();
            checkinRequests.add(new CheckinRequestDTO(booking, payment));
        }

        model.addAttribute("checkinRequests", checkinRequests);
        return "admin/checkinRequests";
    }

    @PostMapping("/checkin-requests/process")
    public String processCheckinRequest(
            @RequestParam Long paymentId,
            @RequestParam Long bookingId,
            @RequestParam String action) {
        
        Payment payment = paymentService.getPaymentById(paymentId);
        Booking booking = bookingService.getBookingById(bookingId);

        if (payment == null || booking == null) {
            return "redirect:/admin/checkin-requests?error=Invalid request";
        }

        if ("approve".equals(action)) {
            payment.setStatus("APPROVED");
            booking.setStatus("ACTIVE");
        } else if ("reject".equals(action)) {
            payment.setStatus("REJECTED");
            booking.setStatus("CANCELLED");
            // Make the room available again
            booking.getRoom().setAvailable(true);
        }

        paymentService.updatePayment(payment);
        bookingService.updateBooking(booking);

        return "redirect:/admin/checkin-requests?success=Request processed";
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        // Check if admin already exists
        try {
            if (adminService.adminExists()) {
                model.addAttribute("error", "Admin already exists. Only one admin is allowed in the system.");
                return "admin/register";
            }
        } catch (Exception e) {
            model.addAttribute("error", "Error checking admin existence. Please try again.");
            return "admin/register";
        }
        
        // Initialize an empty DTO for the form
        AdminRegistrationDTO dto = new AdminRegistrationDTO.Builder().build();
        model.addAttribute("admin", dto);
        return "admin/register";
    }

    @PostMapping("/register")
    public String registerAdmin(@ModelAttribute("admin") AdminRegistrationDTO dto, 
                              RedirectAttributes redirectAttributes,
                              Model model) {
        try {
            // Validate required fields
            if (dto.getUsername() == null || dto.getUsername().trim().isEmpty() ||
                dto.getPassword() == null || dto.getPassword().trim().isEmpty() ||
                dto.getName() == null || dto.getName().trim().isEmpty() ||
                dto.getEmail() == null || dto.getEmail().trim().isEmpty()) {
                model.addAttribute("error", "All fields are required");
                return "admin/register";
            }

            adminService.registerAdmin(dto);
            redirectAttributes.addFlashAttribute("success", "Admin registered successfully! Please login.");
            return "redirect:/admin/login";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "admin/register";
        } catch (Exception e) {
            model.addAttribute("error", "An unexpected error occurred. Please try again.");
            return "admin/register";
        }
    }

    @GetMapping("/profile")
    public String viewProfile(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        try {
            User admin = adminService.getAdminByUsername(userDetails.getUsername());
            model.addAttribute("admin", admin);
            return "admin/profile";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "redirect:/admin/dashboard";
        }
    }

    @GetMapping("/profile/edit")
    public String editProfile(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        try {
            User admin = adminService.getAdminByUsername(userDetails.getUsername());
            AdminProfileUpdateDTO updateDTO = new AdminProfileUpdateDTO();
            updateDTO.setUsername(admin.getUsername());
            updateDTO.setName(admin.getName());
            updateDTO.setEmail(admin.getEmail());
            
            model.addAttribute("admin", updateDTO);
            return "admin/edit-profile";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "redirect:/admin/profile";
        }
    }

    @PostMapping("/profile/update")
    public String updateProfile(
            @AuthenticationPrincipal UserDetails userDetails,
            @ModelAttribute("admin") AdminProfileUpdateDTO updateDTO,
            RedirectAttributes redirectAttributes) {
        try {
            adminService.updateAdminProfile(userDetails.getUsername(), updateDTO);
            redirectAttributes.addFlashAttribute("success", "Profile updated successfully!");
            return "redirect:/admin/profile";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/admin/profile/edit";
        }
    }

    @GetMapping("/rooms/add")
    public String showAddRoomForm(Model model) {
        model.addAttribute("room", new Room());
        model.addAttribute("rooms", roomManagementFacade.getAllRooms());
        return "admin/addRoom";
    }

    @PostMapping("/rooms/add")
    public String addRoom(@ModelAttribute Room room, RedirectAttributes redirectAttributes) {
        roomManagementFacade.addRoom(room);
        redirectAttributes.addFlashAttribute("success", "Room added successfully!");
        return "redirect:/admin/rooms/add";
    }

    @GetMapping("/rooms/delete/{id}")
    public String deleteRoom(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        roomManagementFacade.deleteRoom(id);
        redirectAttributes.addFlashAttribute("success", "Room deleted successfully!");
        return "redirect:/admin/rooms/add";
    }

    @GetMapping("/complaints")
    public String viewComplaints(Model model) {
        model.addAttribute("complaints", complaintService.getAllComplaints());
        model.addAttribute("maintenanceStaff", complaintService.getAllMaintenanceStaff());
        return "admin/complaints";
    }

    @PostMapping("/complaints/allocate-staff")
    public String allocateStaff(@RequestParam Long complaintId, 
                               @RequestParam String staffName) {
        try {
            complaintService.allocateStaff(complaintId, staffName);
            return "redirect:/admin/complaints?success=Staff allocated successfully";
        } catch (RuntimeException e) {
            return "redirect:/admin/complaints?error=" + e.getMessage();
        }
    }

    @PostMapping("/complaints/resolve")
    public String resolveComplaint(@RequestParam Long complaintId, 
                                 @RequestParam String resolution) {
        try {
            complaintService.resolveComplaint(complaintId, resolution);
            return "redirect:/admin/complaints?success=Complaint resolved successfully";
        } catch (RuntimeException e) {
            return "redirect:/admin/complaints?error=" + e.getMessage();
        }
    }

    @GetMapping("/checkout-requests")
    public String viewCheckoutRequests(Model model) {
        List<CheckoutRequest> requests = checkoutRequestRepository.findAll();
        model.addAttribute("requests", requests);
        return "admin/checkoutRequests";
    }

    @PostMapping("/checkout-requests/{id}/approve")
    public String approveCheckoutRequest(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            CheckoutRequest request = checkoutRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Checkout request not found"));
            
            request.setStatus(CheckoutStatus.APPROVED);
            checkoutRequestRepository.save(request);
            
            // Update booking status
            Booking booking = request.getBooking();
            booking.setActive(false);
            booking.setEndDate(request.getCheckoutDate());
            bookingRepository.save(booking);
            
            // Update room status
            Room room = booking.getRoom();
            room.setAvailable(true);
            roomRepository.save(room);
            
            redirectAttributes.addFlashAttribute("successMessage", "Checkout request approved successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error approving checkout request: " + e.getMessage());
        }
        return "redirect:/admin/checkout-requests";
    }

    @PostMapping("/checkout-requests/{id}/reject")
    public String rejectCheckoutRequest(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            CheckoutRequest request = checkoutRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Checkout request not found"));
            
            request.setStatus(CheckoutStatus.REJECTED);
            checkoutRequestRepository.save(request);
            
            redirectAttributes.addFlashAttribute("successMessage", "Checkout request rejected successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error rejecting checkout request: " + e.getMessage());
        }
        return "redirect:/admin/checkout-requests";
    }

    // Additional admin routes can be added here
    // For example: /admin/tenants, /admin/rooms, etc.
} 