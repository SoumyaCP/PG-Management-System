package com.pgmanagement.pgms.service;

import com.pgmanagement.pgms.model.MonthlyPayment;
import com.pgmanagement.pgms.model.Tenant;
import com.pgmanagement.pgms.model.Booking;
import com.pgmanagement.pgms.model.Payment;
import com.pgmanagement.pgms.repository.MonthlyPaymentRepository;
import com.pgmanagement.pgms.repository.TenantRepository;
import com.pgmanagement.pgms.repository.BookingRepository;
import com.pgmanagement.pgms.repository.PaymentRepository;
import com.pgmanagement.pgms.patterns.PaymentGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

@Service
public class MonthlyPaymentService {
    private final MonthlyPaymentRepository monthlyPaymentRepository;
    private final TenantRepository tenantRepository;
    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final PaymentGateway paymentGateway;

    @Autowired
    public MonthlyPaymentService(
            MonthlyPaymentRepository monthlyPaymentRepository,
            TenantRepository tenantRepository,
            BookingRepository bookingRepository,
            PaymentRepository paymentRepository) {
        this.monthlyPaymentRepository = monthlyPaymentRepository;
        this.tenantRepository = tenantRepository;
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
        this.paymentGateway = PaymentGateway.getInstance();
        this.paymentGateway.initialize();
    }

    public List<MonthlyPayment> getAllPayments() {
        return monthlyPaymentRepository.findAll();
    }

    public List<MonthlyPayment> getPaymentsByTenantId(Long tenantId) {
        return monthlyPaymentRepository.findByTenantId(tenantId);
    }

    @Transactional
    public MonthlyPayment makePayment(MonthlyPayment payment) {
        payment.setStatus("PENDING"); // Set initial status as pending
        return monthlyPaymentRepository.save(payment);
    }

    @Transactional
    public void approvePayment(Long paymentId) {
        MonthlyPayment payment = monthlyPaymentRepository.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        
        if (!"PAID".equals(payment.getStatus())) {
            throw new RuntimeException("Payment is not in PAID status");
        }
        
        payment.setStatus("APPROVED");
        monthlyPaymentRepository.save(payment);
    }

    @Transactional
    public void rejectPayment(Long paymentId) {
        MonthlyPayment payment = monthlyPaymentRepository.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        
        if (!"PAID".equals(payment.getStatus())) {
            throw new RuntimeException("Payment is not in PAID status");
        }
        
        payment.setStatus("REJECTED");
        monthlyPaymentRepository.save(payment);
    }

    public boolean hasExistingPaymentForMonth(Long tenantId, String month) {
        // Check if there's any payment that is either PAID or APPROVED for this month
        return monthlyPaymentRepository.existsByTenantIdAndMonthAndStatusIn(
            tenantId, 
            month, 
            Arrays.asList("PAID", "APPROVED")
        );
    }

    @Transactional
    public MonthlyPayment makePayment(Long tenantId, BigDecimal amount, String month, String paymentMethod) {
        // Check if tenant exists
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new RuntimeException("Tenant not found"));

        // Check if tenant has an active booking
        Booking activeBooking = bookingRepository.findByTenantIdAndActive(tenantId, true)
                .orElseThrow(() -> new RuntimeException("No active booking found"));

        // Check if initial check-in payment is approved
        Payment initialPayment = paymentRepository.findByBookingId(activeBooking.getId());
        if (initialPayment == null || !"APPROVED".equals(initialPayment.getStatus())) {
            throw new RuntimeException("Initial check-in payment must be approved before making monthly payments");
        }

        // Check if payment already exists for this month
        if (hasExistingPaymentForMonth(tenantId, month)) {
            throw new RuntimeException("Payment already exists for this month");
        }

        // Validate payment amount
        if (!paymentGateway.validatePayment(amount)) {
            throw new RuntimeException("Invalid payment amount");
        }

        // Process payment through payment gateway
        boolean paymentProcessed = paymentGateway.processPayment(
            amount, 
            paymentMethod, 
            "Monthly payment for " + month + " - Room " + activeBooking.getRoom().getRoomNumber()
        );

        if (!paymentProcessed) {
            throw new RuntimeException("Payment processing failed");
        }

        // Create and save monthly payment
        MonthlyPayment payment = new MonthlyPayment();
        payment.setTenant(tenant);
        payment.setRoom(activeBooking.getRoom());
        payment.setAmount(amount);
        payment.setMonth(month);
        payment.setPaymentDate(LocalDateTime.now());
        payment.setStatus("PAID");
        payment.setPaymentMethod(paymentMethod);

        return monthlyPaymentRepository.save(payment);
    }

    public List<MonthlyPayment> getTenantPayments(Long tenantId) {
        // Verify tenant exists
        if (!tenantRepository.existsById(tenantId)) {
            throw new RuntimeException("Tenant not found");
        }
        return monthlyPaymentRepository.findByTenantId(tenantId);
    }

    public String getCurrentMonth() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-yyyy"));
    }

    public boolean canMakePaymentForMonth(Long tenantId, String month) {
        List<MonthlyPayment> monthPayments = monthlyPaymentRepository.findByTenantIdAndMonth(tenantId, month);
        
        // If no payments exist for this month, payment is allowed
        if (monthPayments.isEmpty()) {
            return true;
        }
        
        // If all existing payments are rejected, new payment is allowed
        return monthPayments.stream()
                .allMatch(payment -> "REJECTED".equals(payment.getStatus()));
    }

    public List<MonthlyPayment> findByTenantIdAndMonth(Long tenantId, String month) {
        return monthlyPaymentRepository.findByTenantIdAndMonth(tenantId, month);
    }
} 